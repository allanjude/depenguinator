/*	$NetBSD: md2.h,v 1.2 2003/10/27 00:12:43 lukem Exp $	*/

/* We unconditionally use the NetBSD MD2 in libnbcompat. */
#include "nbtool_config.h"
#include "../../include/md2.h"
