/*	$NetBSD: tzfile.h,v 1.1 2002/01/31 22:43:49 tv Exp $	*/

#include "../../include/tzfile.h"
