/*	$NetBSD: mpool.h,v 1.1 2002/01/21 20:04:37 tv Exp $	*/

#include "../../include/mpool.h"
