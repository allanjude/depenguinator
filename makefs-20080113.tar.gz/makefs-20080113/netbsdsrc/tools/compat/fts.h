/*	$NetBSD: fts.h,v 1.2 2003/10/27 00:12:43 lukem Exp $	*/

/* We unconditionally use the NetBSD fts(3) in libnbcompat. */
#include "nbtool_config.h"
#include "../../include/fts.h"
