/*	$NetBSD: db.h,v 1.4 2006/10/16 19:44:23 apb Exp $	*/

#include "nbtool_config.h"
#ifndef __BIT_TYPES_DEFINED__
#define __BIT_TYPES_DEFINED__
#endif
#include "../../include/db.h"
