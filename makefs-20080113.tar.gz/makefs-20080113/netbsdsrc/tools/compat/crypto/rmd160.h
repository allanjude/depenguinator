/* $NetBSD: rmd160.h,v 1.2 2006/10/27 22:32:45 mrg Exp $ */

/* We unconditionally use the NetBSD RMD160 in libnbcompat. */
#include "nbtool_config.h"
#include "../../sys/sys/rmd160.h"
