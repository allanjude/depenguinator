/*	$NetBSD: md5.h,v 1.3 2003/10/27 00:12:43 lukem Exp $	*/

/* We unconditionally use the NetBSD MD5 in libnbcompat. */
#include "nbtool_config.h"
#include "../../sys/sys/md5.h"
