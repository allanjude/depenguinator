/*	$NetBSD: dir.h,v 1.1 2003/05/14 00:30:27 dbj Exp $	*/

#include "../../../../sys/ufs/ufs/dir.h"
