/*	$NetBSD: ffs_extern.h,v 1.1 2003/05/14 00:30:26 dbj Exp $	*/

#include "../../../../sys/ufs/ffs/ffs_extern.h"
