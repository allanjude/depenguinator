/*	$NetBSD: nl_types.h,v 1.1 2002/01/29 10:20:32 tv Exp $	*/

#ifdef _NLS_PRIVATE
#include "../../include/nl_types.h"
#endif
