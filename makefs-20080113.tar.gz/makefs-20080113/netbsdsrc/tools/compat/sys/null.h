/*	$NetBSD: null.h,v 1.1.2.2 2007/07/21 12:50:51 liamjfoy Exp $	*/

#include "../../../sys/sys/null.h"
