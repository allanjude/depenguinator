/*	$NetBSD: sha2.h,v 1.1 2006/10/27 22:32:45 mrg Exp $	*/

#include "../../../sys/sys/sha2.h"
