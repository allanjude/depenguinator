/*	$NetBSD: sha1.h,v 1.1 2006/10/29 06:17:08 dogcow Exp $	*/

/* We unconditionally use the NetBSD SHA1 in libnbcompat. */
#include "nbtool_config.h"
#include "../../sys/sys/sha1.h"
