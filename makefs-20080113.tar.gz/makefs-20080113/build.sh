#!/bin/sh

export LANG=C
export TOOLDIR=`pwd`/netbsdbin
export USETOOLS=yes
export NETBSDSRCDIR=`pwd`/netbsdsrc
export MAKEFLAGS="-de -m ${NETBSDSRCDIR}/share/mk -X"
mkdir -p ${TOOLDIR} ${TOOLDIR}/bin
( cd ${NETBSDSRCDIR}/tools/make && sh configure && sh buildmake.sh )
cp ${NETBSDSRCDIR}/tools/make/nbmake ${TOOLDIR}/bin/make
( cd ${NETBSDSRCDIR}/tools/host-mkdep && ${TOOLDIR}/bin/make dependall )
cp ${NETBSDSRCDIR}/tools/host-mkdep/host-mkdep ${TOOLDIR}/bin/nbhost-mkdep
( cd ${NETBSDSRCDIR}/tools/compat && ${TOOLDIR}/bin/make dependall )
( cd ${NETBSDSRCDIR}/tools/makefs && ${TOOLDIR}/bin/make dependall )
